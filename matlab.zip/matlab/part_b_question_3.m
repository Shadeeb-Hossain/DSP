% Name : Shadeeb Hossain 
% ID : sh7492 
h = [1, 0.8];


g = [0, -0.8];


convolution = conv(h, g);  % Finding the convolution and according
                           % to question it should be delta 


stem(0:length(h)-1, h, 'LineWidth', 2, 'MarkerSize', 10);   % This is the 
                                                             % plot for
                                                             % h(n)
hold on;

stem(0:length(g)-1, g, 'LineWidth', 2, 'MarkerSize', 10); % This is the
                                                           % plot for g(n)

stem(0:length(convolution)-1, convolution, 'LineWidth', 2, 'MarkerSize', 10);
hold off;

xlabel('n');
ylabel('Amplitude');
title('Impulse Response and Convolution');
legend('h(n)','g(n)','h(n)*g(n)');
saveas(gcf, 'convolution_plot.pdf');
