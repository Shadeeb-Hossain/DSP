%% Name: Shadeeb Hossain 
%% ID : sh7492

n = -5:20;
h = -double(n == 0) + 0.5 * (n >= 0); % Equation for h (given) 


g = 0.5.^ (n) .* (n >= 0); % Found from solving 
                           % See report for clarification 

convolution = conv(h, g);


stem(n, h, 'LineWidth', 2, 'MarkerSize', 10);
hold on;
stem(n, g, 'LineWidth', 2, 'MarkerSize', 10);
stem(-(length(convolution)-1)/2:(length(convolution)-1)/2, convolution, 'LineWidth', 2, 'MarkerSize', 10);
hold off;

xlabel('n');
ylabel('Amplitude');
title('Impulse Response and Convolution');
legend('h(n)', 'g(n)', 'h(n)*g(n)');

saveas(gcf, 'convolution_plot.pdf');
