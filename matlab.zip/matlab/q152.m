% Name: Shadeeb Hossain 
% ID : sh7492

h = [1, 3.5, 1.5];

H = tf(h, 1);


g = conv(h, [1, 3.5, 1.5]); % This is just derived
                            % See the report for 
                            % the derivation (b)

convolution = conv(h, g);


n = 0:length(convolution)-1;
stem(n, convolution, 'LineWidth', 2, 'MarkerSize', 10);


xlabel('n');
ylabel('Amplitude');
title('Convolution of h(n) and g(n)');

% Verify if the result is Kronecker delta
is_delta = all(convolution == [1, zeros(1, length(convolution)-1)]); % Check if the convolution is Kronecker delta
disp([' convolution ', num2str(is_delta)]);
