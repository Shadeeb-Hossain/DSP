%% Name: Shadeeb Hossain 
%% ID : sh7492

h = [1, zeros(1,9), 0.8]; 

N = length(h);
g = zeros(1, N);
g(1) = 0.5; 

convolution = conv(h, g);

n = 0:length(h)-1;


subplot(3, 1, 1);
stem(n, h, 'LineWidth', 2, 'MarkerSize', 10);
xlabel('n');
ylabel('Amplitude');
title('Impulse Response h(n)');

subplot(3, 1, 2);
stem(n, g, 'LineWidth', 2, 'MarkerSize', 10);
xlabel('n');
ylabel('Amplitude');
title('Impulse Response g(n)');

subplot(3, 1, 3);
n_conv = 0:length(convolution)-1;
stem(n_conv, convolution, 'LineWidth', 2, 'MarkerSize', 10);
xlabel('n');
ylabel('Amplitude');
title('Convolution of h(n) and g(n)');

sgtitle('Impulse Responses and Convolution');
